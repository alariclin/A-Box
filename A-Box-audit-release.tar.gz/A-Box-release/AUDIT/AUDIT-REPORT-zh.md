# A-Box 全面审计、修复与验证报告

> 对象：`/Users/alaric/Downloads/A-Box`（install.sh 原 16330 行 / 897,860 字节；data/sni-candidates.txt 4315 行 / 4311 条候选）
> 结论版本：`v173`（原 `v172` → 审计修复版）
> 生成时间：2026-10-11（UTC）

## 0. 一句话结论

原脚本整体结构严谨、安全设计成熟（mountinfo 权威挂载探测、HMAC 备份、digest 信任根、原子写、事务回滚），但经逐行全文审计 + 隔离回归，确认并修复了 **15 类可复现缺陷**，其中 4 类会造成功能失效（流量状态、单协议 Xray 启停、ASN 查询、恢复清理吞错），若干类会造成“故障时销毁唯一恢复材料”或供应链校验退化。修复后所有隔离回归与真实核心配置校验通过。

**重要声明：本报告不承诺“绝对零 bug”。** 已实测部分与“仍需真实 Linux VPS / 真实客户端互通验证”的部分严格分开，见第 7 节。

---

## 1. 执行方式与边界

- **环境**：macOS arm64（本机，非目标 Linux）。脚本面向 Linux；本机**不执行** `main`、安装、卸载、改防火墙、改 DNS/时区、启动服务或 ACME。
- **测试工具**：为绕开坏工具，从 GNU 镜像编译 Bash 5.3（源码 sha256 `0d5cd86965f869a26cf64f4b71be7b96f90a3ba8b3d74e27e8e9d9d5550f31ba`）；从官方 Release 下载 ShellCheck 0.11.0（digest `339b930feb1ea764467013cc1f72d09cd6b869ebf1013296ba9055ab2ffbd26f`）；从官方 GitHub Release 按 API digest 校验下载 Xray v26.7.28 / sing-box v1.14.2 / Hysteria v2.13.0。
- **全文人工审读覆盖**：install.sh 全 16330 行（1–6500、4800–8000、8001–16330 三段交叉，无缺口）；sni-candidates.txt 全 4315 行；全部 README、LICENSE、mirrors/README、docs/GLOBAL-BEST。
- **上游核验**：web_search 因缺 API key 不可用；改用官方文档/API。确认 Xray `v26.7.28` 真实存在但 `prerelease=true`（属兼容性 pin，非最新 stable，脚本注释已如实说明）；sing-box `v1.14.2` stable 存在；Hysteria `app/v2.13.0` 存在。

---

## 2. 已确认并修复的缺陷

### 高优先级（会造成功能失效）

1. **流量配对状态空周期解析错误**（原 4688/4742–4747，及生成 traffic_monitor.sh 内 6973–6976 同类）
   `read_traffic_pair_fields` 对 `RUNNING|` 输出 `RUNNING\n\n`；`pair=$(...)` 剥尾换行后只剩 `RUNNING`，被当作“封锁周期”返回，`set_desired_state` 再传给周期校验而失败。修复：命令替换后显式检测换行，空周期返回不存在；两处（主函数与生成 monitor）均已改。

2. **单协议 Xray 的 --start/--stop 永远拒绝有效部署**（原 14646）
   `expected_managed_services` xray 分支 `printf xray; [[ MODE==*ALL* ]] && printf hysteria`，非 ALL 模式末命令返回 1，命令替换 `|| die` 令 VISION/XHTTP/SS 全部报“部署状态无效”。修复：显式 `if [[ MODE == ALL ]]` 并保证返回 0。

3. **ASN 缓存权限校验永远失败 + 未初始化变量**（原 10113、10107/10137–10139）
   GNU `stat -c %a` 对 0700 目录输出 `700`，`^0700$` 拒绝正常目录，ASN/国家/组织查询永不执行，SNI 风险评分（同 ASN/同地区/CDN 惩罚）失效；修正后 403/500/缺 jq 会在 `set -u` 下触发 unbound variable。修复：`^0?700$`、初始化 `asn/country/org`、`valid_public_ip` 先置 guard。

4. **恢复清理吞掉删除失败**（原 12004–12005）
   源缺失分支 `rm -rf` 失败仍 `return 0`。修复：`rm ... || return 1` 并校验目标确已消失。

### 中优先级（安全/供应链）

5. **远端脚本校验被短路掩盖**（原 4138）：`(validate_abox_script_file; validate_ota_version_direction)` 分号使首项失败被末项成功掩盖。改为 `&&`。

6. **灾备核心下载绕过已取得的上游 digest**（原 4578–4607）：三路失败后仅比对“镜像自身 SHA256SUMS”，可引入与上游不同的核心。修复：灾备同样强制 `verify_github_asset_digest "$tmp_file" "$digest"`；另对可更换 `ABOX_CORE_MIRROR_BASE` 增加 URL 校验与“非官方源是发布者信任决策”的注释。

7. **目录 nlink 下界正则错误**（原 2025、5018）：`^[2-9][0-9]*$` 拒绝合法 10–19/100–199 等（8 个直接子目录即 nlink=10），会使 ACME/配置目录权限准备误失败。改为数值 `>=2`。

8. **Fail2Ban 过滤器误用 POSIX 字符类 + 验证门槛过低**（原 5158、4951）：Python failregex 内 `[[:space:]]` 不匹配空白，Xray `invalid request` 样本失配；`>=2` 门槛让另两条认证样本掩盖该失配。修复：改用 `\s`，门槛改为对全部 3 类样本逐条断言。

9. **JSON `id` 键的裸 UUID 未脱敏**（原 10780–10813）：Xray `settings.clients[].id` 非 `uuid` 键，诊断脱敏可原样输出。修复：对规范 UUID 值做全局脱敏（Python 路径 + sed 兜底路径）。

10. **Cron 剥离器接受错配/嵌套标记并删除夹在中间的用户任务**（原 10933–10947）：PROBE BEGIN … GEO END 会被整体剥掉。修复：记录区块名、END 必须同名、禁止嵌套与重复，失败即拒改。

11. **Swap 标记删除失败时恢复旧 fstab 指向已删除的 /swapfile**（原 10755–10775）：修复为“文件已清理则保留已清理 fstab 与恢复快照，返回失败，不再恢复过期引用”。

### 事务/回滚健壮性（防止“故障时销毁恢复材料”）

12. **Geo 更新事务**：备份 `cp` 未检查、回滚 `A&&cp||rm` 在 cp 失败时反删目标、EXIT trap 销毁唯一旧副本。改为：备份成功才发布、同目录 staging + 原子 `mv` 恢复、失败不删目标、回滚失败保留 tmpdir、统一 EXIT/信号回滚且重启验证。

13. **自签证书原子更新回滚**：恢复 `cp` 失败仍删唯一旧材料。改为：任一步发布/chmod 失败即统一恢复，恢复失败保留事务目录。

14. **DNS/时区快照**：先删旧快照再建新快照，新快照失败丢唯一恢复材料；DoH `enable --now` 不重载已运行 dnscrypt 的新配置；NM 读取失败仍生成“完整”快照。新增同父目录安全 staging + publish helper，快照完整后才原子替换旧快照、发布失败还原、恢复失败保留材料；DoH 改 `enable → restart → is-active` 逐项失败即回滚并保留。

15. **Wallos 归属/路径/挂载安全与失败假成功**（R05–R08）：仅靠残留 marker 判定容器归属会误停/误删自管同名容器；目录可经符号链接/嵌套挂载逃逸；`docker rm` 失败仍报“已删除”。新增 `wallos_directory_safe`（父链 root:root、目录/marker/backups 权限、db/logos 非链接、无嵌套挂载、树内无非普通文件）、`wallos_container_state`（严格校验 `com.alariclin.abox.managed` label，foreign/查询失败一律拒绝）、`wallos_remove_managed_container`/`wallos_change_managed_container`；全部 install/update/backup/remove 路径接线，删除/重启失败不再假成功、不破坏在用数据。

### 附带小修
- SNI DNS 解析加 `timeout 8`，避免 NSS 停滞绕过探测预算。
- `restore_tree_path` 删除失败不再吞错（同 4）。

---

## 3. 隔离回归结果

安全 harness（`regression.py`，仅 source 去尾 `main "$@"` 后 mock 执行，不调用 main、不做系统修改）：

| 结果 | 说明 |
|---|---|
| **12/12 PASS**（修复版） | 空周期/非空周期、服务枚举返回码、ASN 权限+HTTP 各状态+私网拒绝、恢复删除失败传播、远端校验短路、UUID 脱敏、Cron 错配/嵌套拒绝、Cron 选择性移除、Fail2Ban 3 类样本 |
| **3/12 PASS**（原版复现） | 上述 9 项在原版稳定失败，证明测试能捕获真实回归 |

- 静态：ShellCheck 0.11.0 全文 122 条诊断（**0 error**；113 info、6 warning、3 style）。6 条 warning 逐一复核为“未使用局部变量”或“数组/字符串写法提示”（如 `backups`/`targets` 的 `local` 声明与数组赋值、字符串 append），非正确性缺陷。
- 88 个 heredoc 全部解析，其中 **34 个嵌入 Python 全部 `ast.parse` 通过**；10 个生成 bash 子脚本（防火墙恢复/probe/Geo/traffic/cron/svc fixtures 等）全部 `bash -n` 通过。
- `bash -n` 全文通过；`--help`、`--version` 无害命令实测通过。

---

## 4. 真实核心配置校验（官方 digest 二进制，只 check 不运行/不监听）

| 核心 | 模式 | 结果 |
|---|---|---|
| Xray 26.7.28 | VISION / XHTTP / SS / ALL / VLESS_SS × keepalive on/off | **10/10 Configuration OK**（含完整 geosite 广告规则） |
| sing-box 1.14.2 | VISION / SS / VLESS_SS / HY2 / ALL × keepalive on/off | **10/10 check 通过** |
| 负控 | 注入非法 SS-2022 key | Xray exit 23 / sing-box exit 1，正确拒绝 |

- Geo：Loyalsoldier `geosite.dat`（release `202610102207`）按官方 API digest `sha256:e5d2232b…4af9` 下载并校验一致（11,147,460 字节），Xray 校验未降级删规则。
- **Xray 真实风险告警（非 checker 失败）**：`minClientVer` 改动、`www.microsoft.com` 目标、非 443 监听都会提高封 IP 概率；SS-2022 被标记弃用。默认 SNI/minClientVer 来自原构造器，已在报告中如实转述。
- **Hysteria 未完整配置校验**：v2.13.0 顶层与 `server --help` 均无 `check` 子命令；按限制不启动 server/ACME，故仅验证 version/help，明确标注“未完整验证”。

---

## 5. SNI 候选库实测（本地网络，非 VPS、非全球结论）

对 `data/sni-candidates.txt` 全部 4311 条做 8 并发、证书校验的 TLS1.3 + ALPN 探测（macOS 当前网络）：

| 状态 | 数量 |
|---|---|
| TLS1.3 + h2 验证通过 | 692 |
| TLS1.3（无 h2 ALPN） | 123 |
| DNS 无解析 | 3174（多数为自动生成的子域变体，属预期） |
| TLS 错误 / 证书错误 / 超时 / 网络错误 | 131 / 55 / 72 / 59 |
| 非公网 DNS 应答 | 5 |

**结论**：候选库确实包含大量真实可用的 TLS1.3+h2 目标，但“可用性”与当前网络强相关；脚本本身即按“本地探测后才推荐、绝不静默写入生产 SNI”设计，与本实测结论一致。**本机结果不代表任一目标在用户 VPS 或客户端所在国家可用。** 原始种子文件未删改（本地失败不剔除候选）。

---

## 6. 尚存已知风险 / 建议后续（非本次强制修复项）

1. **文档引用了仓库内不存在的 `.github/workflows/update-mirrors.yml`**（mirrors/README、GLOBAL-BEST 提到灾备 Workflow）。这是文档真实性缺口：要么补该 workflow，要么改文档表述，避免让用户以为镜像已由 CI 自动生成。
2. **Xray 默认 pin `v26.7.28` 为 prerelease**（兼容非 PQ 客户端的有意选择），应在发行说明中提示“非当前 latest stable”。
3. **ShellCheck 6 条 warning** 均为死变量/数组写法提示，可清理但非正确性缺陷。
4. `restore_tree_path` 等少数 `A && B || C` 风格（ShellCheck SC2015 info 级）建议改 if/else，防止未来语义误读；本次已修复其中会销毁材料的 Geo/证书处。
5. 事务 PAIR 状态（traffic）的“提交/停服”短路与快照未含权威 PAIR（middle 审计发现）属更深的健壮性建议，未在本轮纳入强制修复，已在工作记录中留档。

---

## 7. 验证边界（明确区分）

**已实测通过**：全文人工审读、静态解析、隔离回归 12/12、ShellCheck 0 error、真实核心配置 20/20 + 负控、Geo digest、SNI 本地探测、`--help/--version`。

**仍需真实目标环境验证（本机无法证明，不冒称通过）**：
- 真实 Linux（Debian/Ubuntu/RHEL/Alpine × systemd/OpenRC）上的 `--self-test`、`--preflight`、安装/卸载、防火墙/服务/用户权限、恢复与回滚端到端。
- 真实客户端互通：Shadowrocket / Mihomo / Clash Verge / v2rayNG / sing-box / Hysteria 对每种协议的连通与握手。
- Hysteria 配置（无 check 子命令）。
- 各 VPS 服务商网络下的 SNI 可用性、封禁风险。
- 任何“绝对零 bug”声明——本次不做出该承诺。

---

## 8. 产物清单

- 修复版项目：`install.sh`（v173）、`data/sni-candidates.txt`（未改）、README×4、LICENSE、`mirrors/`、`docs/`、3 张图片。
- 审计/验证：`audit-changes.patch`（原→修复 unified diff）、本报告、`regression.py`+结果、`shellcheck-final.json`、`core-tests/`（results.json 20/20 + Geo digest）、`sni-tests/`（summary+csv+json）。
- 校验：对发行归档内每个文件生成 `SHA256SUMS`。

原始文件快照与 sha256 已保存在 `original/`（install.sh 原 `sha256 a0609cb4838803ee6beb9f637f52ee2438ca19e96d53fa28bdcb4e1f065a3d07`）。
