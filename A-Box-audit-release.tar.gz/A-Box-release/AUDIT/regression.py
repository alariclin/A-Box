#!/usr/bin/env python3
"""Safe isolated regression tests; never calls installer main or system services."""
import pathlib,subprocess,tempfile,json,sys,re
source=pathlib.Path(sys.argv[1]); bash=sys.argv[2] if len(sys.argv)>2 else 'bash'
text=source.read_text(); assert text.rstrip().endswith('main "$@"')
records=[]
with tempfile.TemporaryDirectory(prefix='A-Box-regression-') as d:
 root=pathlib.Path(d).resolve(); lib=root/'library.sh'; lib.write_text(text.rsplit('main "$@"',1)[0]); work=root/'work'; work.mkdir()
 def test(name,body,expect=0):
  pre='source "$1"; export PATH=/usr/bin:/bin:/usr/sbin:/sbin; work="$2"; '
  p=subprocess.run([bash,'--noprofile','--norc','-c',pre+body,'test',str(lib),str(work)],text=True,capture_output=True,timeout=30)
  ok=p.returncode==expect; records.append({'test':name,'pass':ok,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}); print(('PASS ' if ok else 'FAIL ')+name,p.returncode)
 test('traffic empty period and desired transitions',r'''read_traffic_pair_fields() { printf '%s\n\n' "$intent"; }; commit_traffic_pair_state() { [[ "$2" == '' ]] || return 42; printf '%s' "$1"; }; for intent in RUNNING MANUAL_STOPPED MAINTENANCE TRAFFIC_BLOCKED; do if get_traffic_block_period; then exit 1; fi; [[ "$(set_desired_state RUNNING)" == RUNNING ]] || exit 2; done''')
 test('traffic nonempty period',r'''read_traffic_pair_fields() { printf 'TRAFFIC_BLOCKED\n2026-10\n'; }; [[ "$(get_traffic_block_period)" == 2026-10 ]]''')
 test('service enumeration all valid mode return codes',r'''clear_abox_env_vars() { :; }; load_abox_env() { :; }; for MODE in VISION XHTTP SS VLESS_SS; do CORE=xray; v=$(expected_managed_services); rc=$?; [[ "$rc" == 0 && "$v" == xray ]] || exit 1; done; CORE=xray MODE=ALL; [[ "$(expected_managed_services)" == $'xray\nhysteria' ]]''')
 test('ASN 700 cache with successful HTTP',r'''mkdir "$work/asn1"; stat() { case "$2" in %u|%g) printf 0;; %a) printf 700;; esac; }; curl() { printf '{"org":"AS13335 Cloudflare","country":"US"}\n200'; }; v=$(asn_lookup_ip 1.1.1.1 "$work/asn1"); [[ "$v" == $'asn=AS13335\tcountry=US\torg=AS13335 Cloudflare' ]]''')
 test('ASN HTTP errors do not trigger nounset',r'''mkdir "$work/asn2"; stat() { case "$2" in %u|%g) printf 0;; %a) printf 700;; esac; }; for status in 403 500 000; do curl() { printf '\n%s' "$status"; }; v=$(asn_lookup_ip 1.1.1.1 "$work/asn2"); rc=$?; [[ "$rc" == 0 && "$v" == $'asn=unknown\tcountry=unknown\torg=unknown' ]] || exit 1; /bin/rm -f "$work/asn2/1.1.1.1"; done''')
 test('ASN private address denied before HTTP',r'''mkdir "$work/asn3"; curl() { touch "$work/unsafe-http"; return 42; }; if asn_lookup_ip 127.0.0.1 "$work/asn3"; then exit 1; fi; [[ ! -e "$work/unsafe-http" ]]''')
 test('restore absent source propagates deletion failure',r'''path_is_mountpoint() { return 1; }; path_tree_has_mountpoint() { return 1; }; rm() { return 42; }; if restore_tree_path "$work/backup" "$work/live"; then exit 1; fi; exit 0''')
 test('remote script validation failure stops install',r'''curl() { local out; while (($#)); do if [[ "$1" == -o ]]; then out="$2"; shift 2; else shift; fi; done; printf "ABOX_BUILD='safe'\nABOX_BUILD_EPOCH=99999999999\n" > "$out"; }; validate_abox_script_file() { return 1; }; validate_ota_version_direction() { touch "$work/should-not-version"; return 0; }; confirm_ota_script_hash() { return 0; }; write_if_changed() { touch "$work/should-not-install"; }; (install_remote_abox_script_guarded https://example.org/a "$work/dest") >/dev/null 2>&1; rc=$?; [[ "$rc" != 0 && ! -e "$work/should-not-version" && ! -e "$work/should-not-install" ]]''')
 test('bare UUID redacted in JSON and logs',r'''u=11111111-1111-4111-8111-111111111111; v=$(printf '{"clients":[{"id":"%s"}],"id":42,"safe":"visible"}' "$u" | redact_secrets_stream); [[ "$v" != *"$u"* && "$v" == *visible* && "$v" == *42* ]] || exit 1; v=$(printf 'client id %s visible' "$u" | redact_secrets_stream); [[ "$v" != *"$u"* && "$v" == *visible* ]]''')
 test('cron mismatched and nested markers rejected',r'''printf '%s\n' '# A-Box PROBE BEGIN' '* * * * * user-task' '# A-Box GEO END' > "$work/cron.bad"; if strip_abox_cron_blocks_from_file "$work/cron.bad" "$work/out"; then exit 1; fi; printf '%s\n' '# A-Box PROBE BEGIN' '# A-Box GEO BEGIN' '# A-Box GEO END' '# A-Box PROBE END' > "$work/cron.bad"; if strip_abox_cron_blocks_from_file "$work/cron.bad" "$work/out"; then exit 2; fi''')
 test('cron valid selective removal preserves unrelated tasks',r'''printf '%s\n' 'user-before' '# A-Box PROBE BEGIN' 'abox-task' '# A-Box PROBE END' 'user-after' '# A-Box GEO BEGIN' 'geo-task' '# A-Box GEO END' > "$work/cron.good"; strip_abox_cron_blocks_from_file "$work/cron.good" "$work/out" PROBE || exit 1; v=$(<"$work/out"); [[ "$v" == *user-before* && "$v" == *user-after* && "$v" == *geo-task* && "$v" != *abox-task* ]]''')
 # Exercise actual embedded Python regex strings after replacing Fail2Ban HOST placeholder.
 match=re.search(r"<<'EOF_F2B_FILTER'.*?\n(.*?)\nEOF_F2B_FILTER",text,re.S); assert match
 rules=[]
 for l in match.group(1).splitlines():
  if l.startswith('failregex = '): rules.append(l[len('failregex = '):])
  elif l.lstrip().startswith('^'): rules.append(l.strip())
 host=r'(?:[0-9]{1,3}(?:\.[0-9]{1,3}){3}|[0-9A-Fa-f:]+)'
 regexes=[re.compile(r.replace('<HOST>',host)) for r in rules]
 samples=['process connection from 203.0.113.7:54321: message authentication failed','authentication failed from [2001:db8::7]:443','proxy/vless/inbound: invalid request from 198.51.100.9:44321 > proxy/vless/encoding']
 ok=all(any(r.match(s) for r in regexes) for s in samples)
 records.append({'test':'actual Fail2Ban patterns match every representative class','pass':ok}); print(('PASS ' if ok else 'FAIL ')+'Fail2Ban regex sample classes')
out=pathlib.Path(__file__).resolve().parent/('regression-'+source.parent.name+'.json'); out.write_text(json.dumps(records,indent=2)); print('Summary',sum(r['pass'] for r in records),'/',len(records)); sys.exit(0 if all(r['pass'] for r in records) else 1)
